# Instructions

Run the following commands to view the output of the example.

- `npm install`
- `npm test`
