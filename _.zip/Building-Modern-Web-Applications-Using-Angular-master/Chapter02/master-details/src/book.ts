export class Book {
  isbn: number;
  title: string;
  authors: string;
  published: string;
  description: string;
  coverImage: string;
}
