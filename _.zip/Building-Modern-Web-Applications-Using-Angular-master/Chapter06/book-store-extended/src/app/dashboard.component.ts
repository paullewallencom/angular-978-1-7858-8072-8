import { Component } from '@angular/core';

@Component({
  selector: 'dashboard',
  template: `<h2>Dashboard</h2>`
})
export class DashboardComponent {
}
