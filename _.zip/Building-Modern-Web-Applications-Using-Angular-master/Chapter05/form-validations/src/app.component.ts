import { Component } from '@angular/core';

@Component({
  selector: 'forms-app',
  template: '<registration-form></registration-form>'
})
export class AppComponent {
}